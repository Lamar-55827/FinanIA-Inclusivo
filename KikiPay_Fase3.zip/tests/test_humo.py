"""
Prueba de humo SIN Streamlit real: usa un Streamlit simulado para ejecutar app.py,
recorrer todas las secciones y disparar los callbacks. Detecta NameError, KeyError,
errores de lógica en callbacks, etc. NO prueba el comportamiento visual real de Streamlit.
Ejecutar: python -m unittest discover -s tests -v
"""
import os
import runpy
import sys
import types
import unittest

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)


class SS(dict):
    __getattr__ = dict.get
    def __setattr__(self, k, v): self[k] = v
    def __delattr__(self, k): del self[k]


class Ctx:
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getattr__(self, n): return fake_fn(n)
    def __iter__(self): return iter([Ctx(), Ctx(), Ctx(), Ctx()])


def fake_fn(nombre):
    def f(*a, **k):
        return Ctx()
    return f


def crear_stub():
    st = types.ModuleType("streamlit")
    st.session_state = SS()
    st.sidebar = Ctx()
    st.llamadas = []

    def con_clave(valor_por_defecto):
        def f(*a, **k):
            clave = k.get("key")
            if clave is not None and clave in st.session_state:
                return st.session_state[clave]
            valor = valor_por_defecto(a, k)
            if clave is not None:
                st.session_state[clave] = valor   # Streamlit real también guarda el valor del widget
            return valor
        return f

    def opciones(a, k):
        if "options" in k: o = k["options"]
        else: o = a[1] if len(a) > 1 else []
        o = list(o)
        return None if k.get("index", 0) is None or not o else o[0]

    st.radio = con_clave(opciones)
    st.selectbox = con_clave(opciones)
    st.select_slider = con_clave(opciones)
    st.multiselect = con_clave(lambda a, k: [])
    st.toggle = con_clave(lambda a, k: False)
    st.checkbox = con_clave(lambda a, k: False)
    st.number_input = con_clave(lambda a, k: k.get("value", k.get("min_value", 0)))
    st.text_input = con_clave(lambda a, k: "")
    st.date_input = con_clave(lambda a, k: k.get("value"))
    st.file_uploader = con_clave(lambda a, k: None)
    st.button = lambda *a, **k: False
    st.form_submit_button = lambda *a, **k: False
    st.download_button = lambda *a, **k: False
    st.columns = lambda spec, **k: [Ctx() for _ in range(spec if isinstance(spec, int) else len(spec))]
    for n in ("container", "expander", "form", "spinner"):
        setattr(st, n, lambda *a, **k: Ctx())
    st.__getattr__ = lambda n: fake_fn(n)  # PEP 562: cualquier otra función es no-op
    return st


def ejecutar(estado=None, **sesion):
    st = crear_stub()
    st.session_state.update(sesion)
    sys.modules["streamlit"] = st
    sys.modules.pop("kiki_logica", None)
    g = runpy.run_path(os.path.join(RAIZ, "app.py"), run_name="__main__")
    return st, g


class TestHumo(unittest.TestCase):
    def test_todas_las_secciones(self):
        for seccion in ("inicio", "dinero", "compras", "organizo", "ahorro", "retos", "kiki", "progreso", "experiencia"):
            for datos in (False, True):
                st, g = ejecutar(seccion=seccion)
                if datos:
                    g["cb_cargar_demo"]()
                    st.session_state["seccion"] = seccion
                    g["main"]()   # segunda ejecución con datos de ejemplo
                self.assertIn("movimientos", st.session_state)

    def test_todas_las_secciones_con_cada_modo_y_nivel(self):
        for modo in ("Pictogramas", "Imagen y número", "Solo números"):
            for nivel in (1, 2, 3):
                for seccion in ("dinero", "compras", "retos"):
                    ejecutar(seccion=seccion, prefs=dict(
                        nombre="Ana *x*", tamano="Muy grande", contraste=True, pistas=True,
                        reducir=True, pictos=False, modo=modo, dificultad=nivel))

    def test_callbacks_de_dinero_y_retos(self):
        st, g = ejecutar(seccion="dinero")
        ss = st.session_state
        ej = ss["ej_dinero"]
        g["cb_comprobar_dinero"]()                    # sin elegir
        self.assertEqual(ss["msgs"]["dinero"][0], "aviso")
        ss[f"resp_dinero_{ej['n']}"] = ej["total"] + 1000
        g["cb_comprobar_dinero"]()                    # incorrecta
        self.assertFalse(ej["resuelto"])
        ss[f"resp_dinero_{ej['n']}"] = ej["total"]
        g["cb_comprobar_dinero"]()                    # correcta
        self.assertTrue(ej["resuelto"])
        self.assertEqual((ss["progreso"]["dinero_ok"], ss["progreso"]["dinero_total"]), (1, 2))
        g["cb_nuevo_dinero"]()
        self.assertNotEqual(ss["ej_dinero"]["n"], ej["n"])

        ss["sum_op"], ss["sum_a"], ss["sum_b"], ss["sum_res"] = "Sumar", 20, 5, 25
        g["cb_comprobar_suma"]()
        self.assertEqual(ss["msgs"]["suma"][0], "ok")
        ss["sum_op"], ss["sum_a"], ss["sum_b"] = "Restar", 5, 20
        g["cb_comprobar_suma"]()
        self.assertEqual(ss["msgs"]["suma"][0], "aviso")

        g["cb_nuevo_reto"]()
        reto = ss["reto"]
        ss[f"resp_reto_{reto['n']}"] = reto["correcta"]
        g["cb_comprobar_reto"]()
        self.assertTrue(reto["resuelto"])

    def test_organizo_y_compras(self):
        st, g = ejecutar(seccion="compras")
        ss = st.session_state
        ss["compra_prod"] = "Cuaderno"
        g["cb_registrar_compra"]()
        self.assertEqual(len(ss["movimientos"]), 1)
        self.assertEqual(ss["movimientos"][0]["cantidad"], 35)
        self.assertEqual(ss["progreso"]["compras"], 1)
        # Regresión del error original: todas las secciones con movimientos guardados
        for seccion in ("inicio", "organizo", "progreso", "compras"):
            ss["seccion"] = seccion
            g["main"]()
        ss["borrar_mov"] = ss["movimientos"][0]["id"]
        g["cb_borrar_movimiento"]()
        self.assertEqual(ss["movimientos"], [])

    def test_metas(self):
        st, g = ejecutar(seccion="ahorro")
        ss = st.session_state
        g["cb_cargar_demo"]()
        meta = ss["metas"][0]
        antes = meta["ahorrado"]
        ss[f"meta_add_{meta['id']}"] = 30.0
        g["cb_agregar_ahorro"](meta["id"])
        self.assertEqual(ss["metas"][0]["ahorrado"], antes + 30)
        self.assertEqual(ss[f"meta_add_{meta['id']}"], 0.0)
        g["cb_agregar_ahorro"](meta["id"])           # cantidad 0 -> aviso, sin cambios
        self.assertEqual(ss["metas"][0]["ahorrado"], antes + 30)
        g["cb_borrar_meta"](meta["id"])
        self.assertEqual(len(ss["metas"]), 1)
        g["main"]()

    def test_datos_respaldo_borrado_y_navegacion(self):
        st, g = ejecutar(seccion="experiencia")
        ss = st.session_state
        g["cb_cargar_demo"]()
        ss["prefs"]["nombre"] = "Luis"
        import kiki_logica as kl
        texto = kl.exportar_estado(ss["movimientos"], ss["metas"], ss["prefs"], ss["progreso"])

        class Archivo:
            def getvalue(self): return texto.encode("utf-8")
        g["cb_borrar_todo"]()
        self.assertEqual((ss["movimientos"], ss["metas"]), ([], []))
        self.assertEqual(ss["prefs"]["nombre"], "Luis")      # preferencias se conservan
        ss["w_respaldo"] = Archivo()
        g["cb_restaurar"]()
        self.assertEqual(len(ss["movimientos"]), 6)
        self.assertEqual(ss["msgs"]["datos"][0], "ok")
        ss["w_respaldo"] = type("A", (), {"getvalue": lambda self: b"basura"})()
        g["cb_restaurar"]()
        self.assertEqual(ss["msgs"]["datos"][0], "error")
        self.assertEqual(len(ss["movimientos"]), 6)          # no pierde datos si el archivo es malo
        g["cb_ir"]("retos")
        self.assertEqual(ss["seccion"], "retos")
        ss["w_tamano"] = "Grande"
        g["cb_pref"]("tamano")
        self.assertEqual(ss["prefs"]["tamano"], "Grande")

    def test_kiki(self):
        st, g = ejecutar(seccion="kiki")
        ss = st.session_state
        ss["kiki_tema"] = "ahorro"
        g["cb_explicar_tema"]()
        self.assertEqual(ss["kiki_hist"][0]["titulo"], "¿Qué es ahorrar?")
        g["main"]()


if __name__ == "__main__":
    unittest.main()
