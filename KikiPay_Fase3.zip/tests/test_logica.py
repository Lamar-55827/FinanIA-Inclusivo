"""Pruebas de la lógica pura (sin Streamlit). Ejecutar: python -m unittest discover -s tests -v"""
import json
import os
import random
import sys
import unittest
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import kiki_logica as kl  # noqa: E402


class TestMovimientos(unittest.TestCase):
    def test_totales_tras_guardar(self):
        # Regresión del error de la versión anterior (KeyError por 'Tipo' vs 'tipo')
        movs = []
        for tipo, cant, cat in (("Ingreso", 100, "Apoyo familiar"), ("Gasto", 35, "Educación")):
            m, e = kl.crear_movimiento(tipo, cant, cat, "", date(2026, 1, 1), len(movs) + 1)
            self.assertIsNone(e)
            movs.append(m)
        self.assertEqual(kl.totales(movs), (100, 35, 65))

    def test_validaciones(self):
        for cant in (0, -5, "abc", None, float("nan"), float("inf"), True, 10**9):
            m, e = kl.crear_movimiento("Gasto", cant, "Otros", "", date.today(), 1)
            self.assertIsNone(m, cant)
            self.assertTrue(e)
        self.assertIsNotNone(kl.crear_movimiento("Otro", 5, "Otros", "", date.today(), 1)[1])
        self.assertIsNotNone(kl.crear_movimiento("Gasto", 5, "Apoyo familiar", "", date.today(), 1)[1])
        self.assertIsNotNone(kl.crear_movimiento("Gasto", 5, "Otros", "", "no-fecha", 1)[1])

    def test_descripcion_por_defecto(self):
        m, _ = kl.crear_movimiento("Gasto", 5, "Transporte", "   ", date.today(), 1)
        self.assertEqual(m["descripcion"], "Transporte")

    def test_gastos_por_categoria(self):
        movs, _, _ = kl.datos_demo(date(2026, 1, 10))
        d = kl.gastos_por_categoria(movs)
        self.assertEqual(d["Educación"], 35)
        self.assertEqual(sum(d.values()), 92)


class TestCambio(unittest.TestCase):
    def test_ejemplo_del_documento(self):
        r = kl.calcular_cambio(35, 50)
        self.assertTrue(r["suficiente"])
        self.assertEqual(r["cambio"], 15)

    def test_no_alcanza(self):
        r = kl.calcular_cambio(120, 100)
        self.assertFalse(r["suficiente"])
        self.assertEqual(r["falta"], 20)

    def test_desglose(self):
        self.assertEqual(kl.desglose_cambio(15), [("moneda", 10, 1), ("moneda", 5, 1)])
        self.assertEqual(sum(v * n for _t, v, n in kl.desglose_cambio(388)), 388)
        self.assertEqual(kl.desglose_cambio(0), [])


class TestDinero(unittest.TestCase):
    def test_ejercicios(self):
        for nivel in (1, 2, 3):
            for semilla in range(200):
                ej = kl.generar_ejercicio_dinero(nivel, random.Random(semilla))
                total = sum(v * n for _t, v, n in ej["items"])
                self.assertEqual(ej["total"], total)
                self.assertIn(total, ej["opciones"])
                self.assertEqual(len(set(ej["opciones"])), len(ej["opciones"]))
                self.assertTrue(all(o > 0 for o in ej["opciones"]))

    def test_textos(self):
        items = [("billete", 20, 2), ("moneda", 5, 1)]
        self.assertEqual(kl.expresion_suma(items), "20 + 20 + 5")
        self.assertEqual(kl.conteo_progresivo(items), "$20 → $40 → $45")
        self.assertEqual(kl.describir_piezas(items), "2 billetes de $20, 1 moneda de $5")


class TestMetas(unittest.TestCase):
    def test_flujo(self):
        meta, e = kl.crear_meta("Audífonos", 300, 120, 1)
        self.assertIsNone(e)
        self.assertAlmostEqual(kl.progreso_meta(meta), 0.4)
        nueva, e = kl.agregar_ahorro(meta, 30)
        self.assertEqual(nueva["ahorrado"], 150)
        self.assertEqual(meta["ahorrado"], 120)  # original intacta
        self.assertEqual(kl.falta_meta(nueva), 150)
        self.assertEqual(kl.semanas_para_meta(150, 40), 4)

    def test_validaciones(self):
        self.assertIsNotNone(kl.crear_meta("", 100, 0, 1)[1])
        self.assertIsNotNone(kl.crear_meta("x", 0, 0, 1)[1])
        self.assertIsNotNone(kl.crear_meta("x", 10, -1, 1)[1])
        meta, _ = kl.crear_meta("x", 10, 0, 1)
        self.assertIsNotNone(kl.agregar_ahorro(meta, 0)[1])
        self.assertIsNotNone(kl.agregar_ahorro(meta, "a")[1])

    def test_barra_no_pasa_de_100(self):
        meta, _ = kl.crear_meta("x", 10, 50, 1)
        self.assertEqual(kl.progreso_meta(meta), 1.0)
        self.assertEqual(kl.falta_meta(meta), 0)

    def test_semanas_casos(self):
        self.assertEqual(kl.semanas_para_meta(0, 5), 0)
        self.assertIsNone(kl.semanas_para_meta(10, 0))


class TestRetos(unittest.TestCase):
    def test_todos_los_retos(self):
        for nivel in (1, 2, 3):
            for semilla in range(400):
                r = kl.generar_reto(nivel, random.Random(semilla))
                self.assertIn(r["correcta"], r["opciones"])
                self.assertEqual(len(set(r["opciones"])), len(r["opciones"]))
                self.assertTrue(r["explicacion"] and r["pista"])

    def test_ejemplos_del_documento(self):
        # Se verifica la aritmética de los ejemplos: 50 - 30 = 20 y 100 - 40 = 60
        self.assertEqual(kl.formato_dinero(50 - 30), "$20")
        self.assertEqual(kl.formato_dinero(100 - 40), "$60")


class TestKiki(unittest.TestCase):
    def test_temas(self):
        casos = {
            "¿Qué es ahorrar?": "ahorro", "que es un credito": "credito",
            "¿Qué es el historial crediticio?": "historial", "Buró de Crédito": "sic",
            "tarjeta de débito": "debito", "¿Qué son los intereses?": "interes",
            "transferencia": "transferencia", "¿Qué es una comisión?": "comision",
            "presupuesto": "presupuesto", "¿qué es el saldo?": "saldo",
        }
        for pregunta, esperado in casos.items():
            r = kl.buscar_respuesta(pregunta)
            self.assertEqual(r["tipo"], "respuesta", pregunta)
            self.assertEqual(r["titulo"], kl.entrada_por_id(esperado)["titulo"], pregunta)

    def test_vacia_y_desconocida(self):
        self.assertEqual(kl.buscar_respuesta("   ")["tipo"], "vacia")
        self.assertEqual(kl.buscar_respuesta("xyzzy")["tipo"], "nada")

    def test_asesoria_no_se_da(self):
        r = kl.buscar_respuesta("¿Debo invertir en bitcoin?")
        self.assertEqual(r["tipo"], "asesoria")

    def test_aviso_datos_sensibles(self):
        self.assertTrue(kl.buscar_respuesta("mi NIP es 1234, ¿qué hago?")["aviso"])
        self.assertTrue(kl.buscar_respuesta("tarjeta 4111111111111111")["aviso"])
        self.assertFalse(kl.buscar_respuesta("¿qué es ahorrar?")["aviso"])

    def test_historial_aclara_que_kiki_pay_no_lo_genera(self):
        self.assertIn("no crea historial", kl.entrada_por_id("historial")["texto"])


class TestRespaldo(unittest.TestCase):
    def test_ida_y_vuelta(self):
        movs, metas, _ = kl.datos_demo(date(2026, 3, 1))
        prefs = dict(kl.PREFS_DEFAULT, nombre="Ana", contraste=True, tamano="Grande")
        texto = kl.exportar_estado(movs, metas, prefs, dict(kl.PROGRESO_DEFAULT, retos_ok=3))
        estado, error = kl.importar_estado(texto)
        self.assertIsNone(error)
        self.assertEqual(kl.totales(estado["movimientos"]), kl.totales(movs))
        self.assertEqual(len(estado["metas"]), 2)
        self.assertEqual(estado["prefs"]["nombre"], "Ana")
        self.assertTrue(estado["prefs"]["contraste"])
        self.assertEqual(estado["progreso"]["retos_ok"], 3)
        ids = [m["id"] for m in estado["movimientos"]] + [g["id"] for g in estado["metas"]]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertGreater(estado["sig_id"], max(ids))

    def test_rechaza_basura(self):
        for malo in ("", "no json", "[]", '{"x":1}', '{"kiki_pay_respaldo":99}'):
            self.assertIsNone(kl.importar_estado(malo)[0], malo)
        malo = json.dumps({"kiki_pay_respaldo": 1, "movimientos": [{"tipo": "Gasto", "cantidad": -5}]})
        self.assertIsNotNone(kl.importar_estado(malo)[1])

    def test_prefs_invalidas_se_ignoran(self):
        texto = json.dumps({"kiki_pay_respaldo": 1, "preferencias": {"tamano": "Gigante", "modo": 5, "dificultad": 9}})
        estado, error = kl.importar_estado(texto)
        self.assertIsNone(error)
        self.assertEqual(estado["prefs"], kl.PREFS_DEFAULT)


class TestHabilidades(unittest.TestCase):
    def test_sin_practica(self):
        self.assertEqual(kl.habilidades(kl.PROGRESO_DEFAULT)[0]["Estado"], "Aún sin practicar")


if __name__ == "__main__":
    unittest.main()
